<form role="search" method="get" class="search-form" action="<?php echo home_url( '/' ); ?>">
	<div class="search-area">
		<input type="text" class="search-field" placeholder="Busca" value="" name="s" title="Buscar por:" />
		<input type="image" class="botao-busca" alt="Buscar" src="<?php bloginfo( 'template_url' ); ?>/imagens/icone-busca.png" />
	</div>
</form>